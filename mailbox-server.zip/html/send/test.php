<?php

/**
 * This example shows making an SMTP connection without using authentication.
 */

//Import the PHPMailer class into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

//SMTP needs accurate times, and the PHP time zone MUST be set
//This should be done in your php.ini, but this is how to do it if you don't have access to that
date_default_timezone_set('Etc/UTC');

require './vendor/autoload.php';

//Create a new PHPMailer instance
$mail = new PHPMailer();
//Tell PHPMailer to use SMTP
$mail->isSMTP();
//Enable SMTP debugging
//SMTP::DEBUG_OFF = off (for production use)
//SMTP::DEBUG_CLIENT = client messages
//SMTP::DEBUG_SERVER = client and server messages
$mail->SMTPDebug = SMTP::DEBUG_SERVER;
//Set the hostname of the mail server
$mail->isSendmail();
//We don't need to set this as it's the default value
//$mail->SMTPAuth = false;
//Set who the message is to be sent from
$mail->setFrom('admin@builtup.tech', 'First Last');
//Set an alternative reply-to address
$mail->addReplyTo('admin@builtup.tech', 'First Last');
//Set who the message is to be sent to
$message_id='<CACELDZ5q0Sot1_OowhA7xb2u_YSLC=LQpHd4zT8hvTHCmArypg@mail.gmail.com>';

//$mail->addCustomHeader('In-Reply-To', $message_id);
//$mail->addCustomHeader('References', $message_id);
$mail->ReturnPath='bounce_here@auftera.email';
$mail->addAddress('test-04fccd84@appmaildev.com', 'John iDoe');
$mail->addBcc("response@builtup.tech");

//$mail->addCustomHeader("Return-Path","<ravigorasiya65+gmail.com-bounces@test5.auftera.email>");

//Set the subject line
$mail->Subject = 'PHPMailer SMTP without auth test';
//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
$mail->msgHTML(file_get_contents('contents.html'), __DIR__);
//Replace the plain text body with one created manually
$mail->AltBody = 'This is a plain-text message body';
//Attach an image file
$mail->Body="send test email in db";

//send the message, check for errors
if (!$mail->send()) {
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message sent!';
}


<?php

$get_message_id=$_GET['message_id'];

$get_message_id='CAJSpSQj2nRnm5-DNkvge20kydGpbVw0+NUuJOpbZQmRhWCkNGw@mail.gmail.com';

$file_path="../inbox_mail/<".$get_message_id.">";

$myfile = fopen($file_path, "r") or die("Unable to open file!");

echo fread($myfile,filesize($file_path));

fclose($myfile);


?>

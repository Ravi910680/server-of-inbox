a="This is testtxt file"
s="${a%%\**}"            # remove all text after DOT and store in variable s
sixx=${#a}
vardd=$(( ${#s} )) 
if [ $vardd == $sixx ]
then
 echo "find string"
fi

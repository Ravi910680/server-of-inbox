search_dir=../Maildir/new/
for entry in "$search_dir"/*
do
  echo "$entry"
done

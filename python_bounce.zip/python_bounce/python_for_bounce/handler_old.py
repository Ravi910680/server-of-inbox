import json
import urllib.parse
import pymysql
import eml_parser
import datetime
import email
import bs4
import pybase64
import re
import bs4
import sys


rds_host  = "database-1.c2kbgonwhnk5.us-east-2.rds.amazonaws.com"
name = "admin"
password = "Ravi91068"
db_name = "auftera-crm"

conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)


rds_host="database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com"
name="admin"
password="Ravi91068"
db_name="list_contacts"

list_conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)




def json_serial(obj):
  if isinstance(obj, datetime.datetime):
      serial = obj.isoformat()
      return serial




def get_body_part_of_email(raw_email):
    b=email.message_from_string(raw_email.decode())

    body = ""


    for part in b.walk():
        ctype = part.get_content_type()
        cdispo = str(part.get('Content-Disposition'))



        body = part.get_payload(decode=True)


    return body

def get_body_of_ret_email(raw_email):
    key='diagnostic-code'
    ret_body=""
    for part in raw_email['body']:
        if key in part['content_header']:
            ret_body+=part['content_header'][key][0]
    return ret_body

def check_best_flg_for_status(arr):
    min_val=0;
    name_of_fnd="";
    for val in arr:
        if(min_val<arr[val]):
            min_val=arr[val]
            name_of_fnd=val;
    print(name_of_fnd)
    if(name_of_fnd=="spam"):
        return 2;
    elif(name_of_fnd=="not_exist"):
        return 4;
    elif(name_of_fnd=="tm_out"):
        return 3;

def get_type_of_bounce(body):
    flg_spam=1;
    print(body)
    result_of_good={"not_exist":0,"spam":0,"tm_out":0}

    array_for_hard_bounce={"not_exist":["550","not","exist","double-checking","reach","tried"],"tm_out":["connection","connect","postfix" ,"timed", "out"],"spam":["550","detected","suspicious","low","reputation","spam","blocked","protect"]}
    for tp in array_for_hard_bounce:
        for find_check in array_for_hard_bounce[tp]:
            if(body.find(find_check)>0):

                result_of_good[tp]+=1
    print(result_of_good)
    return (check_best_flg_for_status(result_of_good))








def final_list_name_from_low_name(dir_name):

    dict_for_name={"0_10k_big":"0_10K_big","10_20k_big":"10_20K_big","20k_30k_big":"20K_30K_big","30k_40k_big":"30K_40K_big","40k_big":"40K_Big"}
    return dict_for_name[dir_name]

def getCampDetFromUrl(to_email_arch,tp_sub_stat):
    #tp_sub_stat=4;
    split_arr=to_email_arch.split("/");
    list_conn_curs = list_conn.cursor()

    list_id=split_arr[6];
    con_id=split_arr[5];





    update_query="update `"+list_id+"` set `substatus`='"+str(tp_sub_stat)+"' where con_id='"+con_id+"'"

    print(update_query)
    list_conn_curs.execute(update_query)
    list_conn.commit()






def lambda_handler(file_name):
    data_file=file_name;


    # Get the object from the event and show its content type




    f = open("./Maildir/new/"+data_file, "rb");
    email_body=f.read();





    ep = eml_parser.EmlParser()
    parsed_eml = ep.decode_email_bytes(email_body)





    to=parsed_eml['header']['to']
    email_from=parsed_eml['header']['from']


    if(email_from.split("@")[0]=="mailer-daemon" or email_from.split("@")[0]=="complaints"):


        find_type_of_bounce=get_type_of_bounce(get_body_of_ret_email(parsed_eml));

        body_part_of_pay=get_body_part_of_email(email_body);
        soup = bs4.BeautifulSoup(body_part_of_pay, "html")
        div = soup.find("img", {"id": "track-email-auftera-918758"})
        getCampDetFromUrl(div['src'],find_type_of_bounce);


        to_email=to[0]
        print(to_email)

        #getCampDetFromUrl(to_email)
        #s3.delete_object(Bucket=bucket, Key=key)






    else:
        data_file=key
        #mycursor = conn.cursor()


        sql = "INSERT INTO `recieve_email` (`to`, `file_det`,`from`) VALUES ('"+to[0]+"', '"+data_file+"','"+email_from+"')"


        #mycursor.execute(sql)
        #conn.commit()











file_name=sys.argv[1];
lambda_handler(file_name);

import json
import urllib.parse
import pymysql
import eml_parser
import datetime
import email
import bs4
import pybase64
import re
import bs4
import sys
import os




file_name=sys.argv[1];
file_expo_name=sys.argv[2];



rds_host  = "database-1.c2rgj64hihag.us-east-2.rds.amazonaws.com"
name = "admin"
password = "Ravi91068"
db_name = "auftera-crm"

try:

    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except:
    os.rename("./Maildir/new/"+file_name, "./Maildir/new/"+file_expo_name)
    sys.exit(0)
rds_host="database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com"
name="admin"
password="Ravi91068"
db_name="list_contacts"
try:
    list_conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)

except:
    os.rename("./Maildir/new/"+file_name, "./Maildir/new/"+file_expo_name)
    sys.exit(0)


def json_serial(obj):
  if isinstance(obj, datetime.datetime):
      serial = obj.isoformat()
      return serial




def get_body_part_of_email(raw_email):
    b=email.message_from_string(raw_email.decode())


    body = ""
    ep = eml_parser.EmlParser()



    for part in b.walk():


        ctype = part.get_content_type()
        cdispo = str(part.get('Content-Disposition'))




        body = part.get_payload(decode=True)




    return body

def get_body_of_ret_email(raw_email,key):

    ret_body=""
    for part in raw_email['body']:
        if key in part['content_header']:
            ret_body+=part['content_header'][key][0]
    return ret_body

def check_best_flg_for_status(arr):
    min_val=0;
    name_of_fnd="";
    for val in arr:
        if(min_val<arr[val]):
            min_val=arr[val]
            name_of_fnd=val;
    
    if(min_val==0):
        name_of_fnd="not_exist"
    print(name_of_fnd)
    if(name_of_fnd=="not_exist"):
        return 4;
    elif(name_of_fnd=="tm_out"):
        return 3;
    elif(name_of_fnd=="spam"):
        return 2;


def get_type_of_bounce(body):
    flg_spam=1;
    print(body)
    result_of_good={"not_exist":0,"spam":0,"tm_out":0}

    array_for_hard_bounce={"not_exist":["550","not","exist","double-checking","reach","tried","invalid","rejected","detected","found","MX","mx","host","access","Access","denied","lookup","DNS","dns","found","Recipient","recipient","exist"],"spam":["550","spamhaus","ip","blacklisted","abuse","blacklisted","temporarily","smtp;","detected","suspicious","low","reputation","spam","blocked","unexpected","volume","deferred","accept","Bulk","Guidelines","bulk","guidelines","complaints","protect"],"tm_out":["connection","connect","postfix" ,"timed", "out","try","after","time","lost","connection","handshake","EHLO"]}
    for tp in array_for_hard_bounce:
        for find_check in array_for_hard_bounce[tp]:
            if(body.find(find_check)>0):

                result_of_good[tp]+=1
    return (check_best_flg_for_status(result_of_good))








def final_list_name_from_low_name(dir_name):

    dict_for_name={"0_10k_big":"0_10K_big","10_20k_big":"10_20K_big","20k_30k_big":"20K_30K_big","30k_40k_big":"30K_40K_big","40k_big":"40K_Big"}
    return dict_for_name[dir_name]

def getCampDetFromUrl(to_email_arch,tp_sub_stat,data_file):
    print(tp_sub_stat)


    split_arr=to_email_arch[0].split('@')[0].split("-");
    create_list_name=split_arr[0]+"^"+pybase64.b64encode(str.encode(split_arr[1])).decode();
    print(create_list_name)
    con_id=split_arr[2]




    list_conn_curs = list_conn.cursor()


    update_query="update `"+create_list_name+"` set `substatus`='"+str(tp_sub_stat)+"' where con_id='"+con_id+"'"
    print(update_query)
    #print(update_query)
    list_conn_curs.execute(update_query)
    os.rename("./Maildir/new/"+data_file, "./python_bounce/bounce_mail/"+to_email_arch[0])
    list_conn.commit()
    sys.exit(0)





def lambda_handler(file_name,expo_name):
    data_file=file_name;


    # Get the object from the event and show its content type



    print(data_file)
    f = open("./Maildir/new/"+data_file, "rb");
    email_body=f.read();





    ep = eml_parser.EmlParser()
    parsed_eml = ep.decode_email_bytes(email_body)









    to=parsed_eml['header']['to']
    email_from=parsed_eml['header']['from']
    



    if(email_from.split("@")[0]=="mailer-daemon" or email_from.split("@")[0]=="complaints"):
        if(to[0].split("@")[0]=="postmaster"):
            os.remove("./Maildir/new/"+data_file)
            sys.exit(0)
        else:
            find_type_of_bounce=get_type_of_bounce(get_body_of_ret_email(parsed_eml,'diagnostic-code'));







            getCampDetFromUrl(to,find_type_of_bounce,data_file);
            #os.remove("./Maildir/new/"+data_file)


        #to_email=to[0]
        #print(to_email)

        #getCampDetFromUrl(to_email)
        #s3.delete_object(Bucket=bucket, Key=key)






    else:
       
        mycursor = conn.cursor()
        subject_ln=parsed_eml['header']['subject']
        expo_name=parsed_eml['header']['header']['message-id'][0]
        utc_datetime = datetime.datetime.utcnow()
        date=utc_datetime.strftime("%Y-%m-%d %H:%M:%S")
        print(date)
        try:
        
            in_reply=parsed_eml['header']['header']['in-reply-to'][0]
            print(in_reply)
            update_query="update `recieve_email` set `in-reply`='"+expo_name+"' where file_name='"+in_reply+"'"
            print(update_query)
            mycursor.execute(update_query)
            conn.commit()
        except:
            
            in_reply=''
        
        sql = "INSERT INTO `recieve_email` (`to`, `file_name`,`from`,`subject`,`date`,`in-reply`) VALUES ('"+to[0]+"', '"+expo_name+"','"+email_from+"','"+subject_ln+"','"+date+"','')"
        print(sql)
        os.rename("./Maildir/new/"+data_file, "/var/www/html/inbox_mail/"+expo_name)
        mycursor.execute(sql)
        conn.commit()









lambda_handler(file_name,file_expo_name);

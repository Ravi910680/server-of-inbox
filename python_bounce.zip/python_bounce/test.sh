#!/bin/bash

TARGET=./Maildir/new/
PROCESSED=./python_bounce/processed/

inotifywait -m -e create -e moved_to --format "%f" $TARGET \
        | while read FILENAME
                do
                       name=$(uuidgen)  
                       echo Detected $FILENAME, moving and zipping
                        python3 ./python_bounce/python_for_bounce/handler.py $FILENAME $name
                        chmod -R 777 /var/www/html/inbox_mail
                done

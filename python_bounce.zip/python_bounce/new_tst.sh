TARGET=./Maildir/new
PROCESSED=./python_bounce/processed

for entry in "$TARGET"/*
do

s="${entry%%\**}"
vardd=$(( ${#s} )) 
sixx=${#entry}
echo $sixx
if [ $vardd == $sixx ]
then
echo $entry
   name=$(uuidgen)  
  python3 ./python_bounce/python_for_bounce/handler.py $entry $name
 name=$(uuidgen)  
mv $entry "$PROCESSED/$name"
fi
done
